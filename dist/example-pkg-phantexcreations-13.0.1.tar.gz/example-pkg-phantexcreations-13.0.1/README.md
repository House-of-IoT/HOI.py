# HOI.py
A bot client library for HOI.
 
This library handles the authentication protocol and main task execution for you abstracting the event loop away. To learn more about usage and implementation
please take a look in the docs section of this repository.
