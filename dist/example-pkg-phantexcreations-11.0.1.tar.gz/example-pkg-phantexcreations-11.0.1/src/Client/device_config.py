class Config:
    def __init__(self,port,host,password,tasks,name,type_data):
        self.port = port
        self.host = host
        self.password = password
        self.tasks = tasks
        self.name = name
        self.type = type_data